1. preloader
2. social links
3. tex exp map – increase by mongo, material ui, ant d, nest.js, webpack, pupetter, etc.  
4. describe proj and chalanges
5. contacts block